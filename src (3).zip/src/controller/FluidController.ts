export class FluidController {


    static addEntity() {
        
    }

}