// src/core/PassiveEntity.ts

import { ForegroundEntity } from './ForegroundEntity';

export class PassiveEntity extends ForegroundEntity {

}